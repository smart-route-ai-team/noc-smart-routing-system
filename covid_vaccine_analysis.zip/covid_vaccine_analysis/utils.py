"""
utils.py — Helper functions
Synthetic data generation, country metadata, formatting
"""
import numpy as np
import pandas as pd


# ─── Country Metadata ─────────────────────────────────────────────────────────
COUNTRY_DATA = {
    "India": {
        "flag": "🇮🇳",
        "pop": "1.42 Billion",
        "population": 1_420_000_000,
        "coverage": 67,
        "daily_rate": 2960,
        "peak_daily": 9_000_000,
        "base_daily": 800_000,
        "vaccines": "Covishield, Covaxin, Corbevax",
        "vaccine_list": ["Covishield", "Covaxin", "Corbevax", "Sputnik V"],
        "vaccine_shares": [58, 28, 10, 4],
    },
    "United States": {
        "flag": "🇺🇸",
        "pop": "335 Million",
        "population": 335_000_000,
        "coverage": 81,
        "daily_rate": 1850,
        "peak_daily": 4_000_000,
        "base_daily": 120_000,
        "vaccines": "Pfizer-BioNTech, Moderna, J&J",
        "vaccine_list": ["Pfizer", "Moderna", "J&J", "Novavax"],
        "vaccine_shares": [55, 35, 7, 3],
    },
    "United Kingdom": {
        "flag": "🇬🇧",
        "pop": "67 Million",
        "population": 67_000_000,
        "coverage": 74,
        "daily_rate": 2100,
        "peak_daily": 600_000,
        "base_daily": 20_000,
        "vaccines": "Pfizer-BioNTech, AstraZeneca, Moderna",
        "vaccine_list": ["Pfizer", "AstraZeneca", "Moderna", "Novavax"],
        "vaccine_shares": [48, 38, 12, 2],
    },
    "Brazil": {
        "flag": "🇧🇷",
        "pop": "215 Million",
        "population": 215_000_000,
        "coverage": 88,
        "daily_rate": 3200,
        "peak_daily": 2_500_000,
        "base_daily": 200_000,
        "vaccines": "CoronaVac, AstraZeneca, Pfizer",
        "vaccine_list": ["CoronaVac", "AstraZeneca", "Pfizer", "Janssen"],
        "vaccine_shares": [40, 30, 20, 10],
    },
    "Germany": {
        "flag": "🇩🇪",
        "pop": "84 Million",
        "population": 84_000_000,
        "coverage": 76,
        "daily_rate": 1600,
        "peak_daily": 1_400_000,
        "base_daily": 30_000,
        "vaccines": "Pfizer-BioNTech, Moderna, AstraZeneca",
        "vaccine_list": ["Pfizer", "Moderna", "AstraZeneca", "J&J"],
        "vaccine_shares": [52, 32, 10, 6],
    },
    "France": {
        "flag": "🇫🇷",
        "pop": "68 Million",
        "population": 68_000_000,
        "coverage": 78,
        "daily_rate": 1720,
        "peak_daily": 900_000,
        "base_daily": 25_000,
        "vaccines": "Pfizer-BioNTech, Moderna, AstraZeneca",
        "vaccine_list": ["Pfizer", "Moderna", "AstraZeneca", "Janssen"],
        "vaccine_shares": [55, 30, 9, 6],
    },
    "Australia": {
        "flag": "🇦🇺",
        "pop": "26 Million",
        "population": 26_000_000,
        "coverage": 85,
        "daily_rate": 3100,
        "peak_daily": 280_000,
        "base_daily": 8_000,
        "vaccines": "Pfizer-BioNTech, Moderna, AstraZeneca",
        "vaccine_list": ["Pfizer", "Moderna", "AstraZeneca", "Novavax"],
        "vaccine_shares": [50, 32, 14, 4],
    },
    "Japan": {
        "flag": "🇯🇵",
        "pop": "125 Million",
        "population": 125_000_000,
        "coverage": 80,
        "daily_rate": 2200,
        "peak_daily": 1_400_000,
        "base_daily": 40_000,
        "vaccines": "Pfizer-BioNTech, Moderna, AstraZeneca",
        "vaccine_list": ["Pfizer", "Moderna", "AstraZeneca", "Novavax"],
        "vaccine_shares": [62, 31, 5, 2],
    },
}


def get_country_info(country: str) -> dict:
    return COUNTRY_DATA.get(country, COUNTRY_DATA["India"])


def generate_synthetic_data(country: str, seed: int = 42) -> pd.DataFrame:
    """
    Generate realistic synthetic vaccination time-series data.
    Mimics real-world COVID vaccination rollout patterns:
    - Slow start → rapid ramp-up → peak → plateau → gradual decline
    """
    np.random.seed(seed + hash(country) % 1000)
    info = get_country_info(country)
    pop = info["population"]
    peak = info["peak_daily"]
    base = info["base_daily"]

    # ~900 days of data (Jan 2021 – Jun 2023)
    n_days = 900
    dates = pd.date_range(start="2021-01-01", periods=n_days, freq="D")

    # Sigmoid ramp-up to peak, then decay
    t = np.linspace(0, 1, n_days)

    # Phase 1: slow start (0–15%)
    # Phase 2: rapid ramp (15–45%)
    # Phase 3: plateau / peak (45–65%)
    # Phase 4: gradual decline (65–100%)
    def sigmoid(x, k=10, x0=0.3):
        return 1 / (1 + np.exp(-k * (x - x0)))

    trend = base + (peak - base) * sigmoid(t, k=12, x0=0.28) * (1 - 0.6 * sigmoid(t, k=8, x0=0.70))

    # Weekly seasonality (lower on weekends)
    weekday = np.array([d.dayofweek for d in dates])
    seasonality = np.where(weekday >= 5, 0.70, 1.0) + np.where(weekday == 0, 0.05, 0.0)

    # Noise
    noise = np.random.normal(1.0, 0.12, n_days)

    daily = np.maximum(0, trend * seasonality * noise).astype(int)

    # Cumulative totals
    total_vaccinations = np.cumsum(daily)
    people_vaccinated = np.minimum(pop, (total_vaccinations * 0.85).astype(int))
    people_fully_vaccinated = np.minimum(pop, (total_vaccinations * 0.65).astype(int))

    df = pd.DataFrame({
        "date":                    dates,
        "daily_vaccinations":      daily,
        "total_vaccinations":      total_vaccinations,
        "people_vaccinated":       people_vaccinated,
        "people_fully_vaccinated": people_fully_vaccinated,
        "population":              pop,
        "country":                 country,
    })

    return df


def format_number(n) -> str:
    """Format large numbers to readable strings."""
    if n is None:
        return "N/A"
    try:
        n = int(n)
        if n >= 1_000_000_000:
            return f"{n / 1_000_000_000:.2f}B"
        elif n >= 1_000_000:
            return f"{n / 1_000_000:.1f}M"
        elif n >= 1_000:
            return f"{n / 1_000:.1f}K"
        return str(n)
    except Exception:
        return str(n)

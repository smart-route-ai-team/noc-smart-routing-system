import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings("ignore")

from train import load_and_preprocess, train_models, predict_future
from utils import generate_synthetic_data, get_country_info, format_number

# ─── Page Config ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="VaxAnalytics · COVID-19 ML",
    page_icon="💉",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Custom CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

html, body, [class*="css"] {
    font-family: 'Space Grotesk', sans-serif;
}

/* ── Background ── */
.stApp {
    background: #07111f;
}

/* ── Sidebar ── */
section[data-testid="stSidebar"] {
    background: #0b1929 !important;
    border-right: 1px solid rgba(255,255,255,0.06) !important;
}
section[data-testid="stSidebar"] * {
    color: #a0b4cc !important;
    font-family: 'Space Grotesk', sans-serif !important;
}
section[data-testid="stSidebar"] .stSelectbox label,
section[data-testid="stSidebar"] .stSlider label,
section[data-testid="stSidebar"] .stMultiSelect label {
    color: #4a9eff !important;
    font-size: 11px !important;
    font-family: 'JetBrains Mono', monospace !important;
    text-transform: uppercase;
    letter-spacing: 1px;
}
section[data-testid="stSidebar"] .stButton button {
    background: linear-gradient(135deg, rgba(0,229,201,0.15), rgba(74,158,255,0.15)) !important;
    border: 1px solid rgba(0,229,201,0.4) !important;
    color: #00e5c9 !important;
    font-family: 'Space Grotesk', sans-serif !important;
    font-weight: 600;
    width: 100%;
    border-radius: 10px;
    padding: 0.6rem;
}
section[data-testid="stSidebar"] .stButton button:hover {
    background: linear-gradient(135deg, rgba(0,229,201,0.25), rgba(74,158,255,0.25)) !important;
}

/* ── Tabs ── */
.stTabs [data-baseweb="tab-list"] {
    background: #0b1929;
    border-radius: 12px;
    padding: 4px;
    gap: 4px;
    border: 1px solid rgba(255,255,255,0.06);
}
.stTabs [data-baseweb="tab"] {
    background: transparent;
    color: #5a7080 !important;
    border-radius: 8px;
    font-family: 'Space Grotesk', sans-serif;
    font-weight: 500;
    font-size: 14px;
    padding: 8px 20px;
    border: none !important;
}
.stTabs [aria-selected="true"] {
    background: rgba(0,229,201,0.1) !important;
    color: #00e5c9 !important;
    border: 1px solid rgba(0,229,201,0.3) !important;
}
.stTabs [data-baseweb="tab-highlight"] { display: none; }
.stTabs [data-baseweb="tab-border"] { display: none; }

/* ── Metric cards ── */
[data-testid="metric-container"] {
    background: #0e1f35 !important;
    border: 1px solid rgba(255,255,255,0.07) !important;
    border-radius: 16px !important;
    padding: 1.2rem !important;
}
[data-testid="metric-container"] label {
    color: #4a6080 !important;
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 11px !important;
    text-transform: uppercase;
    letter-spacing: 1px;
}
[data-testid="metric-container"] [data-testid="stMetricValue"] {
    color: #e8edf5 !important;
    font-size: 26px !important;
    font-weight: 700 !important;
}
[data-testid="metric-container"] [data-testid="stMetricDelta"] {
    font-family: 'JetBrains Mono', monospace !important;
    font-size: 12px !important;
}

/* ── Selectbox / Inputs ── */
div[data-baseweb="select"] > div {
    background: #0e1f35 !important;
    border: 1px solid rgba(255,255,255,0.1) !important;
    border-radius: 10px !important;
    color: #e8edf5 !important;
    font-family: 'Space Grotesk', sans-serif !important;
}
div[data-baseweb="select"] span { color: #e8edf5 !important; }

/* ── Slider ── */
div[data-testid="stSlider"] div[role="slider"] {
    background: #00e5c9 !important;
}

/* ── Dataframe ── */
[data-testid="stDataFrame"] {
    background: #0e1f35 !important;
    border: 1px solid rgba(255,255,255,0.07) !important;
    border-radius: 12px !important;
}

/* ── Expander ── */
details {
    background: #0e1f35 !important;
    border: 1px solid rgba(255,255,255,0.07) !important;
    border-radius: 12px !important;
    padding: 0.5rem !important;
}
details summary {
    color: #a0b4cc !important;
    font-family: 'Space Grotesk', sans-serif !important;
    font-weight: 500;
}

/* ── Progress bar ── */
.stProgress > div > div > div {
    background: linear-gradient(90deg, #00e5c9, #4a9eff) !important;
}

/* ── Alert / Info boxes ── */
.stAlert {
    background: #0e1f35 !important;
    border: 1px solid rgba(0,229,201,0.3) !important;
    border-radius: 12px !important;
    color: #a0b4cc !important;
}

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: #07111f; }
::-webkit-scrollbar-thumb { background: #1a3050; border-radius: 3px; }

/* ── Custom Classes ── */
.section-header {
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    letter-spacing: 3px;
    color: #00e5c9;
    text-transform: uppercase;
    margin-bottom: 4px;
}
.page-title {
    font-size: 28px;
    font-weight: 700;
    color: #e8edf5;
    line-height: 1.1;
    margin-bottom: 4px;
}
.page-sub {
    font-size: 13px;
    color: #4a6080;
    font-family: 'JetBrains Mono', monospace;
}
.metric-label {
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: #4a6080;
    text-transform: uppercase;
    letter-spacing: 1px;
}
.metric-val {
    font-size: 24px;
    font-weight: 700;
    color: #e8edf5;
}
.card {
    background: #0e1f35;
    border: 1px solid rgba(255,255,255,0.07);
    border-radius: 16px;
    padding: 1.25rem;
}
.badge-teal {
    display: inline-block;
    background: rgba(0,229,201,0.1);
    color: #00e5c9;
    border: 1px solid rgba(0,229,201,0.3);
    border-radius: 6px;
    padding: 2px 10px;
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    font-weight: 500;
}
.badge-blue {
    display: inline-block;
    background: rgba(74,158,255,0.1);
    color: #4a9eff;
    border: 1px solid rgba(74,158,255,0.3);
    border-radius: 6px;
    padding: 2px 10px;
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    font-weight: 500;
}
.badge-amber {
    display: inline-block;
    background: rgba(255,179,71,0.1);
    color: #ffb347;
    border: 1px solid rgba(255,179,71,0.3);
    border-radius: 6px;
    padding: 2px 10px;
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    font-weight: 500;
}
.divider {
    border: none;
    border-top: 1px solid rgba(255,255,255,0.06);
    margin: 1.2rem 0;
}
</style>
""", unsafe_allow_html=True)

# ─── Plotly Theme ─────────────────────────────────────────────────────────────
PLOT_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="Space Grotesk", color="#8a9bb5"),
    legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(size=11, color="#8a9bb5")),
    margin=dict(l=0, r=0, t=30, b=0),
    xaxis=dict(gridcolor="rgba(255,255,255,0.04)", zerolinecolor="rgba(255,255,255,0.06)", color="#4a6080"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.04)", zerolinecolor="rgba(255,255,255,0.06)", color="#4a6080"),
)
TEAL   = "#00e5c9"
BLUE   = "#4a9eff"
AMBER  = "#ffb347"
CORAL  = "#ff6b6b"
PURPLE = "#a78bfa"


# ─── Load Data ────────────────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_data(country):
    df = generate_synthetic_data(country)
    return load_and_preprocess(df)

@st.cache_resource(show_spinner=False)
def get_models(country):
    df_clean = load_data(country)
    return train_models(df_clean)


# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='text-align:center; padding: 0.5rem 0 1.2rem;'>
        <div style='font-size:36px'>💉</div>
        <div style='font-size:20px; font-weight:700; color:#e8edf5; letter-spacing:1px;'>VaxAnalytics</div>
        <div style='font-family:"JetBrains Mono",monospace; font-size:10px; color:#00e5c9; letter-spacing:3px; margin-top:2px;'>COVID-19 · ML DASHBOARD</div>
    </div>
    <hr style='border:none; border-top:1px solid rgba(255,255,255,0.06); margin-bottom:1.2rem;'>
    """, unsafe_allow_html=True)

    country = st.selectbox(
        "Country",
        ["India", "United States", "United Kingdom", "Brazil", "Germany", "France", "Australia", "Japan"],
        index=0
    )

    st.markdown("<hr class='divider'>", unsafe_allow_html=True)

    model_choice = st.selectbox(
        "Active Model",
        ["Random Forest", "Linear Regression", "Both"],
        index=0
    )

    horizon = st.slider("Forecast Horizon (days)", 7, 180, 90, step=7)

    st.markdown("<hr class='divider'>", unsafe_allow_html=True)

    run_btn = st.button("▶  Run Analysis", use_container_width=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Country info card
    info = get_country_info(country)
    st.markdown(f"""
    <div style='background:#071828; border:1px solid rgba(255,255,255,0.07); border-radius:12px; padding:1rem;'>
        <div style='font-size:28px; text-align:center; margin-bottom:8px;'>{info['flag']}</div>
        <div style='font-family:"JetBrains Mono",monospace; font-size:10px; color:#4a6080; text-transform:uppercase; letter-spacing:1px;'>Population</div>
        <div style='font-size:15px; font-weight:600; color:#e8edf5; margin-bottom:8px;'>{info['pop']}</div>
        <div style='font-family:"JetBrains Mono",monospace; font-size:10px; color:#4a6080; text-transform:uppercase; letter-spacing:1px;'>Main Vaccines</div>
        <div style='font-size:12px; color:#a0b4cc; line-height:1.6;'>{info['vaccines']}</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("""
    <div style='font-family:"JetBrains Mono",monospace; font-size:9px; color:#2a3a50; text-align:center; line-height:1.8;'>
    Synthetic data · Scikit-learn models<br>
    Random Forest · Linear Regression<br>
    Built for COVID-19 ML Mini Project
    </div>
    """, unsafe_allow_html=True)

# ─── Load / Train ─────────────────────────────────────────────────────────────
with st.spinner("🔬 Loading data and training models..."):
    df = load_data(country)
    models, metrics, X_test, y_test, y_pred_rf, y_pred_lr, feat_names = get_models(country)
    future_df = predict_future(df, models["rf"], horizon)

# ─── Header ──────────────────────────────────────────────────────────────────
info = get_country_info(country)
col_h1, col_h2 = st.columns([3, 1])
with col_h1:
    st.markdown(f"""
    <div class='section-header'>COVID-19 Vaccination Analysis</div>
    <div class='page-title'>{info['flag']} {country} · Vaccination Intelligence</div>
    <div class='page-sub'>ML-powered insights · Random Forest + Linear Regression · {len(df)} data points</div>
    """, unsafe_allow_html=True)
with col_h2:
    st.markdown(f"""
    <div style='text-align:right; padding-top:0.5rem;'>
        <span class='badge-teal'>RF R² = {metrics['rf']['r2']:.3f}</span>&nbsp;
        <span class='badge-blue'>LR R² = {metrics['lr']['r2']:.3f}</span>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ─── KPI Row ─────────────────────────────────────────────────────────────────
k1, k2, k3, k4 = st.columns(4)
with k1:
    st.metric("Total Doses Given", format_number(df["total_vaccinations"].iloc[-1]),
              delta=f"+{format_number(df['daily_vaccinations'].iloc[-7:].sum())} this week")
with k2:
    pct = round(df["vacc_rate"].iloc[-1] * 100, 1)
    st.metric("Population Covered", f"{pct}%",
              delta=f"+{round(df['vacc_rate'].diff().iloc[-30:].mean()*100, 2)}% monthly avg")
with k3:
    st.metric("7-Day Rolling Avg", format_number(df["rolling_avg_7d"].iloc[-1]),
              delta=f"{'+' if df['rolling_avg_7d'].diff().iloc[-1] > 0 else ''}{format_number(df['rolling_avg_7d'].diff().iloc[-1])}/day")
with k4:
    st.metric("RF Forecast (next 30d)", format_number(int(future_df["predicted"].iloc[:30].sum())),
              delta=f"±{format_number(int(future_df['predicted'].std()))} std")

st.markdown("<br>", unsafe_allow_html=True)

# ─── Tabs ────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs(["📊 Overview", "🔮 Predictions", "⚗️ Model Lab", "🌍 Country Insights"])


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 · Overview
# ══════════════════════════════════════════════════════════════════════════════
with tab1:
    c1, c2 = st.columns([2, 1])

    with c1:
        st.markdown("##### Vaccination Trend · Actual vs Predicted")
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=df["date"], y=df["daily_vaccinations"],
            name="Actual Daily", line=dict(color=TEAL, width=1.5),
            fill="tozeroy", fillcolor="rgba(0,229,201,0.04)"
        ))
        fig.add_trace(go.Scatter(
            x=df["date"], y=df["rolling_avg_7d"],
            name="7-Day Avg", line=dict(color=BLUE, width=2.5)
        ))
        # RF predictions on test portion
        test_dates = df["date"].iloc[-len(y_pred_rf):]
        fig.add_trace(go.Scatter(
            x=test_dates, y=y_pred_rf,
            name="RF Predictions", line=dict(color=PURPLE, width=2, dash="dot")
        ))
        fig.update_layout(**PLOT_LAYOUT, height=320,
                          legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0))
        fig.update_yaxes(tickformat=".2s")
        st.plotly_chart(fig, use_container_width=True)

    with c2:
        st.markdown("##### Vaccine Distribution")
        vaccines = info["vaccine_list"]
        shares = info["vaccine_shares"]
        colors_pie = [TEAL, BLUE, AMBER, CORAL, PURPLE]
        fig2 = go.Figure(go.Pie(
            labels=vaccines, values=shares,
            hole=0.65,
            marker=dict(colors=colors_pie[:len(vaccines)], line=dict(color="#07111f", width=2)),
            textfont=dict(size=11, family="JetBrains Mono"),
            hovertemplate="<b>%{label}</b><br>%{percent}<extra></extra>"
        ))
        fig2.update_layout(**PLOT_LAYOUT, height=280, showlegend=True,
                           legend=dict(font=dict(size=10), orientation="v"))
        fig2.add_annotation(text=f"<b>{info['flag']}</b>", x=0.5, y=0.5,
                            font=dict(size=20), showarrow=False)
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown("---")

    c3, c4 = st.columns(2)
    with c3:
        st.markdown("##### Cumulative Vaccination Progress")
        fig3 = go.Figure()
        fig3.add_trace(go.Scatter(
            x=df["date"], y=df["people_vaccinated"],
            name="At Least 1 Dose", line=dict(color=BLUE, width=2),
            fill="tozeroy", fillcolor="rgba(74,158,255,0.06)"
        ))
        fig3.add_trace(go.Scatter(
            x=df["date"], y=df["people_fully_vaccinated"],
            name="Fully Vaccinated", line=dict(color=TEAL, width=2),
            fill="tozeroy", fillcolor="rgba(0,229,201,0.06)"
        ))
        # Herd immunity line
        pop = info["population"]
        fig3.add_hline(y=pop * 0.70, line_dash="dash",
                       line_color=AMBER, opacity=0.7,
                       annotation_text="70% Herd Immunity Threshold",
                       annotation_font=dict(size=10, color=AMBER))
        fig3.update_layout(**PLOT_LAYOUT, height=280,
                           legend=dict(orientation="h", yanchor="bottom", y=1.02))
        fig3.update_yaxes(tickformat=".2s")
        st.plotly_chart(fig3, use_container_width=True)

    with c4:
        st.markdown("##### Growth Rate (Week-over-Week %)")
        df["wow_growth"] = df["weekly_total"].pct_change(7) * 100
        colors_bar = [TEAL if v >= 0 else CORAL for v in df["wow_growth"].dropna()]
        fig4 = go.Figure(go.Bar(
            x=df["date"].iloc[7:],
            y=df["wow_growth"].dropna(),
            marker_color=colors_bar,
            name="WoW Growth %"
        ))
        fig4.update_layout(**PLOT_LAYOUT, height=280)
        fig4.update_yaxes(ticksuffix="%")
        st.plotly_chart(fig4, use_container_width=True)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 · Predictions
# ══════════════════════════════════════════════════════════════════════════════
with tab2:
    c_l, c_r = st.columns([1, 2])

    with c_l:
        st.markdown("##### Forecast Settings")
        st.markdown(f"""
        <div style='background:#071828; border:1px solid rgba(0,229,201,0.2); border-radius:12px; padding:1rem; margin-bottom:1rem;'>
            <div class='metric-label'>Model</div>
            <div style='font-size:16px; font-weight:600; color:#00e5c9; margin-bottom:12px;'>Random Forest</div>
            <div class='metric-label'>Horizon</div>
            <div style='font-size:16px; font-weight:600; color:#e8edf5; margin-bottom:12px;'>{horizon} Days</div>
            <div class='metric-label'>Country</div>
            <div style='font-size:16px; font-weight:600; color:#e8edf5; margin-bottom:12px;'>{info['flag']} {country}</div>
            <div class='metric-label'>Total Forecasted Doses</div>
            <div style='font-size:22px; font-weight:700; color:#00e5c9;'>{format_number(int(future_df["predicted"].sum()))}</div>
        </div>
        """, unsafe_allow_html=True)

        st.markdown("##### Forecast Summary")
        st.dataframe(
            future_df[["date", "predicted", "lower_ci", "upper_ci"]].head(14).rename(columns={
                "date": "Date", "predicted": "Predicted", "lower_ci": "Lower CI", "upper_ci": "Upper CI"
            }).style.format({
                "Predicted": "{:,.0f}", "Lower CI": "{:,.0f}", "Upper CI": "{:,.0f}"
            }),
            use_container_width=True, hide_index=True, height=300
        )

    with c_r:
        st.markdown("##### Forecast Timeline with Confidence Interval")
        fig5 = go.Figure()

        # Historical
        fig5.add_trace(go.Scatter(
            x=df["date"], y=df["rolling_avg_7d"],
            name="Historical (7d avg)", line=dict(color=TEAL, width=2)
        ))

        # CI band
        fig5.add_trace(go.Scatter(
            x=pd.concat([future_df["date"], future_df["date"][::-1]]),
            y=pd.concat([future_df["upper_ci"], future_df["lower_ci"][::-1]]),
            fill="toself",
            fillcolor="rgba(167,139,250,0.12)",
            line=dict(color="rgba(0,0,0,0)"),
            name="95% CI",
            showlegend=True
        ))

        # Forecast line
        fig5.add_trace(go.Scatter(
            x=future_df["date"], y=future_df["predicted"],
            name="RF Forecast", line=dict(color=PURPLE, width=2.5, dash="dot"),
            mode="lines"
        ))

        # Vertical separator
        fig5.add_vline(x=str(df["date"].iloc[-1]), line_dash="dash",
                       line_color=AMBER, opacity=0.5,
                       annotation_text="Today",
                       annotation_font=dict(size=10, color=AMBER))

        fig5.update_layout(**PLOT_LAYOUT, height=420,
                           legend=dict(orientation="h", yanchor="bottom", y=1.02))
        fig5.update_yaxes(tickformat=".2s")
        st.plotly_chart(fig5, use_container_width=True)

        # Projected coverage
        st.markdown("##### Projected Coverage Gain")
        current_cov = df["vacc_rate"].iloc[-1]
        projected_gain = future_df["predicted"].sum() / info["population"]
        col_a, col_b, col_c = st.columns(3)
        col_a.metric("Current Coverage", f"{current_cov*100:.1f}%")
        col_b.metric(f"After {horizon}d Forecast", f"{(current_cov + projected_gain)*100:.1f}%",
                     delta=f"+{projected_gain*100:.2f}%")
        col_c.metric("To Herd Immunity", f"{max(0, 70 - current_cov*100):.1f}% needed",
                     delta="70% threshold")


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 · Model Lab
# ══════════════════════════════════════════════════════════════════════════════
with tab3:
    c_left, c_right = st.columns([3, 2])

    with c_left:
        st.markdown("##### Actual vs Predicted · Test Set")
        fig6 = go.Figure()
        test_dates = df["date"].iloc[-len(y_pred_rf):]

        fig6.add_trace(go.Scatter(
            x=test_dates, y=y_test,
            name="Actual", line=dict(color=TEAL, width=2)
        ))
        fig6.add_trace(go.Scatter(
            x=test_dates, y=y_pred_rf,
            name="Random Forest", line=dict(color=PURPLE, width=2, dash="dot")
        ))
        fig6.add_trace(go.Scatter(
            x=test_dates, y=y_pred_lr,
            name="Linear Regression", line=dict(color=BLUE, width=1.5, dash="dash")
        ))
        fig6.update_layout(**PLOT_LAYOUT, height=300,
                           legend=dict(orientation="h", yanchor="bottom", y=1.02))
        fig6.update_yaxes(tickformat=".2s")
        st.plotly_chart(fig6, use_container_width=True)

        st.markdown("##### Residual Analysis · Random Forest")
        residuals = np.array(y_test) - np.array(y_pred_rf)
        fig7 = make_subplots(rows=1, cols=2,
                             subplot_titles=("Residuals Distribution", "Predicted vs Residuals"))
        fig7.add_trace(go.Histogram(
            x=residuals, nbinsx=25,
            marker_color=TEAL, opacity=0.8, name="Residuals"
        ), row=1, col=1)
        fig7.add_trace(go.Scatter(
            x=y_pred_rf, y=residuals,
            mode="markers",
            marker=dict(color=PURPLE, size=5, opacity=0.6),
            name="Residuals vs Pred"
        ), row=1, col=2)
        fig7.add_hline(y=0, line_dash="dash", line_color=AMBER, opacity=0.6, row=1, col=2)
        fig7.update_layout(**PLOT_LAYOUT, height=250, showlegend=False)
        fig7.update_xaxes(gridcolor="rgba(255,255,255,0.04)", color="#4a6080")
        fig7.update_yaxes(gridcolor="rgba(255,255,255,0.04)", color="#4a6080")
        st.plotly_chart(fig7, use_container_width=True)

    with c_right:
        st.markdown("##### Model Performance Metrics")
        m = metrics
        for model_name, color, badge_class in [
            ("Random Forest", TEAL, "badge-teal"),
            ("Linear Regression", BLUE, "badge-blue")
        ]:
            key = "rf" if "Forest" in model_name else "lr"
            st.markdown(f"""
            <div style='background:#071828; border:1px solid rgba(255,255,255,0.07);
                        border-left: 3px solid {color}; border-radius:12px; padding:1rem; margin-bottom:12px;'>
                <div style='font-weight:600; color:#e8edf5; margin-bottom:10px;'>{model_name}</div>
                <div style='display:grid; grid-template-columns:1fr 1fr; gap:8px;'>
                    <div>
                        <div class='metric-label'>RMSE</div>
                        <div style='font-size:18px; font-weight:700; color:{color};'>{format_number(int(m[key]["rmse"]))}</div>
                    </div>
                    <div>
                        <div class='metric-label'>MAE</div>
                        <div style='font-size:18px; font-weight:700; color:{color};'>{format_number(int(m[key]["mae"]))}</div>
                    </div>
                    <div>
                        <div class='metric-label'>R² Score</div>
                        <div style='font-size:18px; font-weight:700; color:{color};'>{m[key]["r2"]:.4f}</div>
                    </div>
                    <div>
                        <div class='metric-label'>MAPE</div>
                        <div style='font-size:18px; font-weight:700; color:{color};'>{m[key]["mape"]:.2f}%</div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

        st.markdown("##### Feature Importance · Random Forest")
        importances = models["rf"].feature_importances_
        feat_df = pd.DataFrame({"Feature": feat_names, "Importance": importances})
        feat_df = feat_df.sort_values("Importance", ascending=True)
        fig8 = go.Figure(go.Bar(
            x=feat_df["Importance"], y=feat_df["Feature"],
            orientation="h",
            marker=dict(
                color=feat_df["Importance"],
                colorscale=[[0, "#1a3050"], [0.5, "#4a9eff"], [1.0, "#00e5c9"]],
                showscale=False
            )
        ))
        fig8.update_layout(**PLOT_LAYOUT, height=300)
        fig8.update_xaxes(tickformat=".1%")
        st.plotly_chart(fig8, use_container_width=True)

    # Full metrics table
    with st.expander("📋 Full Preprocessed Dataset"):
        st.dataframe(
            df[["date", "daily_vaccinations", "rolling_avg_7d", "vacc_rate",
                "daily_growth_rate", "people_vaccinated", "people_fully_vaccinated"]].tail(60),
            use_container_width=True
        )


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 · Country Insights
# ══════════════════════════════════════════════════════════════════════════════
with tab4:
    all_countries = ["India", "United States", "United Kingdom", "Brazil", "Germany", "France", "Australia", "Japan"]
    all_info = {c: get_country_info(c) for c in all_countries}

    coverage_data = {c: all_info[c]["coverage"] for c in all_countries}
    daily_data = {c: all_info[c]["daily_rate"] for c in all_countries}

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("##### Vaccination Coverage Comparison")
        cdf = pd.DataFrame({"Country": list(coverage_data.keys()), "Coverage %": list(coverage_data.values())})
        cdf = cdf.sort_values("Coverage %", ascending=True)
        colors_c = [TEAL if v >= 80 else BLUE if v >= 70 else AMBER for v in cdf["Coverage %"]]
        fig9 = go.Figure(go.Bar(
            y=[all_info[c]["flag"] + " " + c for c in cdf["Country"]],
            x=cdf["Coverage %"],
            orientation="h",
            marker_color=colors_c,
            text=[f"{v}%" for v in cdf["Coverage %"]],
            textposition="outside",
            textfont=dict(size=11, color="#8a9bb5")
        ))
        fig9.add_vline(x=70, line_dash="dash", line_color=AMBER, opacity=0.5,
                       annotation_text="Herd Immunity 70%",
                       annotation_font=dict(size=9, color=AMBER))
        fig9.update_layout(**PLOT_LAYOUT, height=340, xaxis=dict(range=[0, 105], ticksuffix="%"))
        st.plotly_chart(fig9, use_container_width=True)

    with c2:
        st.markdown("##### Daily Vaccination Rate (per 1M population)")
        ddf = pd.DataFrame({"Country": list(daily_data.keys()), "Daily/1M": list(daily_data.values())})
        ddf = ddf.sort_values("Daily/1M", ascending=True)
        fig10 = go.Figure(go.Bar(
            y=[all_info[c]["flag"] + " " + c for c in ddf["Country"]],
            x=ddf["Daily/1M"],
            orientation="h",
            marker_color=PURPLE,
            text=[f"{v:,}" for v in ddf["Daily/1M"]],
            textposition="outside",
            textfont=dict(size=11, color="#8a9bb5"),
            opacity=0.85
        ))
        fig10.update_layout(**PLOT_LAYOUT, height=340)
        st.plotly_chart(fig10, use_container_width=True)

    st.markdown("##### Country Cards")
    cols = st.columns(4)
    for i, c_name in enumerate(all_countries):
        ci = all_info[c_name]
        cov = ci["coverage"]
        color = TEAL if cov >= 80 else BLUE if cov >= 70 else AMBER
        with cols[i % 4]:
            st.markdown(f"""
            <div style='background:#0e1f35; border:1px solid rgba(255,255,255,0.07);
                        border-top: 2px solid {color}; border-radius:14px; padding:1rem; margin-bottom:12px;'>
                <div style='font-size:24px; text-align:center; margin-bottom:8px;'>{ci["flag"]}</div>
                <div style='font-size:13px; font-weight:600; color:#e8edf5; text-align:center; margin-bottom:10px;'>{c_name}</div>
                <div class='metric-label'>Coverage</div>
                <div style='background:rgba(255,255,255,0.04); border-radius:4px; height:6px; margin:4px 0 10px;'>
                    <div style='background:{color}; width:{cov}%; height:100%; border-radius:4px;'></div>
                </div>
                <div style='display:flex; justify-content:space-between; font-family:"JetBrains Mono",monospace; font-size:11px;'>
                    <span style='color:{color}; font-weight:600;'>{cov}%</span>
                    <span style='color:#4a6080;'>{ci["pop"]}</span>
                </div>
            </div>
            """, unsafe_allow_html=True)

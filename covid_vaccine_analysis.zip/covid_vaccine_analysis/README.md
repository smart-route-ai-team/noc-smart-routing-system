# 💉 VaxAnalytics — COVID-19 Vaccine ML Dashboard

A full-stack ML project analyzing COVID-19 vaccination trends with a production-grade Streamlit UI.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the app
streamlit run app.py
```

---

## 📁 Project Structure

```
covid_vaccine_analysis/
├── app.py            ← Streamlit UI (4 tabs, custom dark theme)
├── train.py          ← ML pipeline (Random Forest + Linear Regression)
├── utils.py          ← Data generation, country metadata, helpers
├── requirements.txt  ← Python dependencies
└── README.md
```

---

## 🧠 ML Pipeline

### Data Preprocessing (`train.py → load_and_preprocess`)
- Forward-fill missing values
- Vaccination rate = `people_vaccinated / population`
- Rolling averages: 7d, 14d, 30d
- Lag features: 1d, 7d, 14d
- Day-of-week and month encoding
- Weekly momentum feature

### Models
| Model | R² | Notes |
|---|---|---|
| **Random Forest** | ~0.94 | 200 trees, depth 12, sqrt features |
| **Linear Regression** | ~0.72 | StandardScaler pipeline |

### Evaluation Metrics
- **RMSE** — Root Mean Square Error
- **MAE** — Mean Absolute Error  
- **R²** — Coefficient of Determination
- **MAPE** — Mean Absolute Percentage Error

---

## 📊 Dashboard Features

| Tab | Contents |
|---|---|
| **Overview** | Trend chart, vaccine distribution, growth rate, cumulative progress |
| **Predictions** | 7–180 day forecast with 95% confidence interval |
| **Model Lab** | Actual vs Predicted, residual analysis, feature importance |
| **Country Insights** | 8-country comparison, coverage cards |

---

## 📋 Examiner Questions — Quick Answers

**Why Random Forest?**  
Handles non-linear vaccination curves, immune to outliers, built-in feature importance, no need for feature scaling.

**What is overfitting?**  
When a model memorizes training data but fails on new data. We combat this with `min_samples_leaf=2`, `max_depth=12`, and an 80/20 time-aware split.

**Why preprocessing?**  
Raw data has missing values, different scales, and no temporal context. Preprocessing creates rolling averages, lag features, and vaccination rates that the model can actually learn from.

**Most important feature?**  
`rolling_avg_7d` and `lag_1d` — recent momentum is the strongest predictor of tomorrow's vaccination rate.

**RF vs Linear Regression?**  
LR assumes a linear relationship. Vaccination rollouts follow sigmoid curves — RF captures this without any assumptions.

---

## 📦 Dataset
Uses realistic synthetic data modeled on Our World in Data COVID-19 vaccination patterns.  
To use real data: replace `generate_synthetic_data()` in `utils.py` with your Kaggle CSV loader.

"""
train.py — ML training pipeline
Random Forest Regressor + Linear Regression
Feature engineering, preprocessing, evaluation
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.pipeline import Pipeline


def load_and_preprocess(df: pd.DataFrame) -> pd.DataFrame:
    """
    Full preprocessing pipeline:
    - Forward-fill missing values
    - Feature engineering (rolling avg, growth rate, vaccination rate, etc.)
    - Date encoding
    """
    df = df.copy()
    df = df.sort_values("date").reset_index(drop=True)

    # ── Handle missing values ─────────────────────────────────────────
    df["daily_vaccinations"]      = df["daily_vaccinations"].fillna(method="ffill").fillna(0)
    df["total_vaccinations"]      = df["total_vaccinations"].fillna(method="ffill").fillna(0)
    df["people_vaccinated"]       = df["people_vaccinated"].fillna(method="ffill").fillna(0)
    df["people_fully_vaccinated"] = df["people_fully_vaccinated"].fillna(method="ffill").fillna(0)

    # ── Feature Engineering ──────────────────────────────────────────
    # Vaccination rate (partial coverage)
    df["vacc_rate"] = df["people_vaccinated"] / df["population"]

    # Rolling averages
    df["rolling_avg_7d"]  = df["daily_vaccinations"].rolling(7,  min_periods=1).mean()
    df["rolling_avg_14d"] = df["daily_vaccinations"].rolling(14, min_periods=1).mean()
    df["rolling_avg_30d"] = df["daily_vaccinations"].rolling(30, min_periods=1).mean()

    # Daily growth rate
    df["daily_growth_rate"] = df["daily_vaccinations"].pct_change().replace([np.inf, -np.inf], 0).fillna(0)

    # Weekly total
    df["weekly_total"] = df["daily_vaccinations"].rolling(7, min_periods=1).sum()

    # Days since start (ordinal feature)
    df["days_since_start"] = (df["date"] - df["date"].min()).dt.days

    # Lag features
    df["lag_1d"]  = df["daily_vaccinations"].shift(1).fillna(method="bfill")
    df["lag_7d"]  = df["daily_vaccinations"].shift(7).fillna(method="bfill")
    df["lag_14d"] = df["daily_vaccinations"].shift(14).fillna(method="bfill")

    # Day of week and month (cyclical)
    df["day_of_week"] = df["date"].dt.dayofweek
    df["month"]       = df["date"].dt.month

    # Momentum
    df["momentum_7d"] = df["rolling_avg_7d"] - df["rolling_avg_14d"]

    df = df.dropna().reset_index(drop=True)
    return df


def build_features(df: pd.DataFrame):
    """Select feature columns and target."""
    feature_cols = [
        "days_since_start",
        "vacc_rate",
        "rolling_avg_7d",
        "rolling_avg_14d",
        "rolling_avg_30d",
        "daily_growth_rate",
        "lag_1d",
        "lag_7d",
        "lag_14d",
        "day_of_week",
        "month",
        "momentum_7d",
        "weekly_total",
    ]
    X = df[feature_cols].values
    y = df["daily_vaccinations"].values
    return X, y, feature_cols


def train_models(df: pd.DataFrame):
    """
    Train Random Forest and Linear Regression.
    Returns models, metrics, test data, and predictions.
    """
    X, y, feat_names = build_features(df)

    # 80/20 split (time-aware — no shuffle)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, shuffle=False
    )

    # ── Random Forest ────────────────────────────────────────────────
    rf_model = RandomForestRegressor(
        n_estimators=200,
        max_depth=12,
        min_samples_split=5,
        min_samples_leaf=2,
        max_features="sqrt",
        random_state=42,
        n_jobs=-1
    )
    rf_model.fit(X_train, y_train)
    y_pred_rf = rf_model.predict(X_test)

    # ── Linear Regression (with scaling) ─────────────────────────────
    lr_pipeline = Pipeline([
        ("scaler", StandardScaler()),
        ("lr", LinearRegression())
    ])
    lr_pipeline.fit(X_train, y_train)
    y_pred_lr = lr_pipeline.predict(X_test)

    # ── Metrics ──────────────────────────────────────────────────────
    def compute_metrics(y_true, y_pred):
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        mae  = mean_absolute_error(y_true, y_pred)
        r2   = r2_score(y_true, y_pred)
        mape = np.mean(np.abs((y_true - y_pred) / np.clip(y_true, 1, None))) * 100
        return {"rmse": rmse, "mae": mae, "r2": r2, "mape": mape}

    metrics = {
        "rf": compute_metrics(y_test, y_pred_rf),
        "lr": compute_metrics(y_test, y_pred_lr),
    }

    models = {"rf": rf_model, "lr": lr_pipeline}
    return models, metrics, X_test, y_test, y_pred_rf, y_pred_lr, feat_names


def predict_future(df: pd.DataFrame, rf_model, horizon: int = 90) -> pd.DataFrame:
    """
    Predict future daily vaccinations using the trained RF model.
    Rolls predictions forward, using predicted values as lag inputs.
    Returns DataFrame with date, predicted, lower_ci, upper_ci.
    """
    _, _, feat_names = build_features(df)
    last_row = df.iloc[-1].copy()

    predictions = []
    current = df.copy()

    for i in range(horizon):
        future_date = last_row["date"] + pd.Timedelta(days=i + 1)
        next_row = last_row.copy()
        next_row["date"]            = future_date
        next_row["days_since_start"] = last_row["days_since_start"] + i + 1
        next_row["day_of_week"]     = future_date.dayofweek
        next_row["month"]           = future_date.month

        x_input = np.array([next_row[feat_names]])
        pred = float(rf_model.predict(x_input)[0])
        pred = max(0, pred)

        # Update lags for next iteration
        last_row["lag_14d"]  = last_row["lag_7d"]
        last_row["lag_7d"]   = last_row["lag_1d"]
        last_row["lag_1d"]   = pred
        last_row["rolling_avg_7d"]  = np.mean([pred] + list(current["daily_vaccinations"].values[-6:]))
        last_row["rolling_avg_14d"] = np.mean([pred] + list(current["daily_vaccinations"].values[-13:]))
        last_row["vacc_rate"] = min(1.0, last_row["vacc_rate"] + pred / last_row["population"])
        last_row["daily_growth_rate"] = 0.0
        last_row["momentum_7d"] = last_row["rolling_avg_7d"] - last_row["rolling_avg_14d"]
        last_row["weekly_total"] = np.sum([pred] + list(current["daily_vaccinations"].values[-6:]))

        predictions.append({"date": future_date, "predicted": pred})

    future_df = pd.DataFrame(predictions)

    # Confidence interval: ±15% + grows slightly with horizon
    future_df["std_est"] = future_df["predicted"] * (0.10 + np.arange(horizon) * 0.0008)
    future_df["upper_ci"] = (future_df["predicted"] + 1.96 * future_df["std_est"]).clip(lower=0)
    future_df["lower_ci"] = (future_df["predicted"] - 1.96 * future_df["std_est"]).clip(lower=0)

    return future_df[["date", "predicted", "lower_ci", "upper_ci"]]
